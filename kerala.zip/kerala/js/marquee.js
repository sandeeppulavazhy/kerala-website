    
window.onload = function () {
    function scroll(pos)
    {
        var txt = "Read about Festivals and events in Kerala";
        var output = "";
        var screen = document.getElementById("wordscroller");
        for (var i = 0; i < pos; i++)
        {
            output += txt.charAt(i);
        }
        output += txt.charAt(pos);
        screen.innerHTML = output;
        pos++;
        if (pos != txt.length)
        {
            window.setTimeout(function () { scroll(pos); }, 100);
        }
        else
        {
screen.innerHTML = output+'&nbsp;&nbsp;<a href="festivals.html">Read>></a>'
            window.setTimeout(function () { scroll(0); }, 3000);
        }

    }
    scroll(0);
	
}